import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TodoList = () => {
    const [todos, setTodos] = useState([]);
    const [newTodo, setNewTodo] = useState('');

    useEffect(() => {
        axios.get('/api/todos')
            .then(response => {
                setTodos(response.data);
            })
            .catch(error => {
                console.error(error);
            });
    }, []);

    const handleAddTodo = () => {
        axios.post('/api/todos', { title: newTodo, description: '', isCompleted: false, dueDate: new Date() })
            .then(response => {
                setTodos([...todos, response.data]);
                setNewTodo('');
            })
            .catch(error => {
                console.error(error);
            });
    };

    const handleToggleCompleted = (id) => {
        axios.put(`/api/todos/${id}`, { isCompleted: !todos.find(todo => todo.id === id).isCompleted })
            .then(response => {
                setTodos(todos.map(todo => todo.id === id ? { ...todo, isCompleted: !todo.isCompleted } : todo));
            })
            .catch(error => {
                console.error(error);
            });
    };

    return (
        <div>
            <h1>Todo List</h1>
            <input type="text" value={newTodo} onChange={(e) => setNewTodo(e.target.value)} />
            <button onClick={handleAddTodo}>Add Todo</button>
            <ul>
                {todos.map(todo => (
                    <li key={todo.id}>
                        <input type="checkbox" checked={todo.isCompleted} onChange={() => handleToggleCompleted(todo.id)} />
                        <span>{todo.title}</span>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default TodoList;