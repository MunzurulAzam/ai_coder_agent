import numpy as np

def main():
    # Get user input
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))

    # Perform calculations
    sum_result = num1 + num2
    product_result = num1 * num2

    # Display results
    print(f"The sum of {num1} and {num2} is: {sum_result}")
    print(f"The product of {num1} and {num2} is: {product_result}")

if __name__ == "__main__":
    main()