# Project Overview
This project is a simple Python script that demonstrates basic programming concepts. The script takes user input, performs calculations, and displays the results.

# How to Run the Project
To run the project, follow these steps:
1. Navigate to the project directory: `cd simple_python_script`
2. Activate the virtual environment:
    * On Windows: `venv\Scripts\activate`
    * On macOS or Linux: `source venv/bin/activate`
3. Run the script: `python src/main.py`
4. Follow the prompts to enter two numbers, and the script will display the sum and product of the numbers.