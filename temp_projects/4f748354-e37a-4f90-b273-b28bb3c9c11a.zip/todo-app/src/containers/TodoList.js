import React, { useState, useEffect } from 'react';
import TodoItem from '../components/TodoItem';

const TodoList = () => {
    const [todoItems, setTodoItems] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchTodoItems = async () => {
            const response = await fetch('api/todoitems');
            const data = await response.json();
            setTodoItems(data);
            setLoading(false);
        };
        fetchTodoItems();
    }, []);

    const handleDelete = async (id) => {
        await fetch(`api/todoitems/${id}`, { method: 'DELETE' });
        setTodoItems(todoItems.filter((todoItem) => todoItem.id !== id));
    };

    const handleToggleCompleted = async (id) => {
        const response = await fetch(`api/todoitems/${id}`, { method: 'PATCH' });
        const data = await response.json();
        setTodoItems(todoItems.map((todoItem) => todoItem.id === id ? data : todoItem));
    };

    return (
        <div>
            <h1>Todo List</h1>
            {loading ? (
                <p>Loading...</p>
            ) : (
                <ul>
                    {todoItems.map((todoItem) => (
                        <li key={todoItem.id}>
                            <TodoItem todoItem={todoItem} onDelete={handleDelete} onToggleCompleted={handleToggleCompleted} />
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default TodoList;