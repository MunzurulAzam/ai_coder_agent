import React from 'react';

const TodoItem = ({ todoItem, onDelete, onToggleCompleted }) => {
    return (
        <div>
            <h2>{todoItem.title}</h2>
            <p>{todoItem.description}</p>
            <p>Due Date: {todoItem.dueDate}</p>
            <p>Completed: {todoItem.isCompleted ? 'Yes' : 'No'}</p>
            <button onClick={() => onDelete(todoItem.id)}>Delete</button>
            <button onClick={() => onToggleCompleted(todoItem.id)}>Toggle Completed</button>
        </div>
    );
};

export default TodoItem;