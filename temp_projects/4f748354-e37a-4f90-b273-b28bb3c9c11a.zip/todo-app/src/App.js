import React from 'react';
import TodoList from './containers/TodoList';

const App = () => {
    return (
        <div>
            <TodoList />
        </div>
    );
};

export default App;