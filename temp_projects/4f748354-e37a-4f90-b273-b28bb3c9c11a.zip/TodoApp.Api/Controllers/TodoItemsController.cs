using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TodoApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoItemsController : ControllerBase
    {
        private readonly ITodoItemService _todoItemService;

        public TodoItemsController(ITodoItemService todoItemService)
        {
            _todoItemService = todoItemService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TodoItem>>> GetTodoItems()
        {
            return await _todoItemService.GetTodoItemsAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TodoItem>> GetTodoItem(int id)
        {
            return await _todoItemService.GetTodoItemAsync(id);
        }

        [HttpPost]
        public async Task<ActionResult<TodoItem>> CreateTodoItem(TodoItem todoItem)
        {
            return await _todoItemService.CreateTodoItemAsync(todoItem);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<TodoItem>> UpdateTodoItem(int id, TodoItem todoItem)
        {
            return await _todoItemService.UpdateTodoItemAsync(id, todoItem);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteTodoItem(int id)
        {
            await _todoItemService.DeleteTodoItemAsync(id);
            return NoContent();
        }
    }
}