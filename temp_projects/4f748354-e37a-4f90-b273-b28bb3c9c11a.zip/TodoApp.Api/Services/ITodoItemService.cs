using System.Collections.Generic;
using System.Threading.Tasks;

namespace TodoApp.Api.Services
{
    public interface ITodoItemService
    {
        Task<IEnumerable<TodoItem>> GetTodoItemsAsync();
        Task<TodoItem> GetTodoItemAsync(int id);
        Task<TodoItem> CreateTodoItemAsync(TodoItem todoItem);
        Task<TodoItem> UpdateTodoItemAsync(int id, TodoItem todoItem);
        Task DeleteTodoItemAsync(int id);
    }
}