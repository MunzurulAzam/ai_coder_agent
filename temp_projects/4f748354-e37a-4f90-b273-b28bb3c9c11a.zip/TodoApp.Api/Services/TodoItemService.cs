using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TodoApp.Api.Services
{
    public class TodoItemService : ITodoItemService
    {
        private readonly TodoAppDbContext _dbContext;

        public TodoItemService(TodoAppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<TodoItem>> GetTodoItemsAsync()
        {
            return await _dbContext.TodoItems.ToListAsync();
        }

        public async Task<TodoItem> GetTodoItemAsync(int id)
        {
            return await _dbContext.TodoItems.FindAsync(id);
        }

        public async Task<TodoItem> CreateTodoItemAsync(TodoItem todoItem)
        {
            _dbContext.TodoItems.Add(todoItem);
            await _dbContext.SaveChangesAsync();
            return todoItem;
        }

        public async Task<TodoItem> UpdateTodoItemAsync(int id, TodoItem todoItem)
        {
            var existingTodoItem = await _dbContext.TodoItems.FindAsync(id);
            if (existingTodoItem != null)
            {
                existingTodoItem.Title = todoItem.Title;
                existingTodoItem.Description = todoItem.Description;
                existingTodoItem.DueDate = todoItem.DueDate;
                existingTodoItem.IsCompleted = todoItem.IsCompleted;
                await _dbContext.SaveChangesAsync();
            }
            return existingTodoItem;
        }

        public async Task DeleteTodoItemAsync(int id)
        {
            var todoItem = await _dbContext.TodoItems.FindAsync(id);
            if (todoItem != null)
            {
                _dbContext.TodoItems.Remove(todoItem);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}