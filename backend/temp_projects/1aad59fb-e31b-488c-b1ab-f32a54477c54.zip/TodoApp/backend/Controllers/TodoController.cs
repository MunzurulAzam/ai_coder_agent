
```csharp
using Microsoft.AspNetCore.Mvc;
using Supabase.Net;
using System.Threading.Tasks;

namespace TodoApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoController : ControllerBase
    {
        private readonly ISupabaseClient _supabaseClient;

        public TodoController(ISupabaseClient supabaseClient)
        {
            _supabaseClient = supabaseClient;
        }

        [HttpGet]
        public async Task<IActionResult> GetTodos()
        {
            var todos = await _supabaseClient.From<TodoItem>().Select("*");
            return Ok(todos);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTodo([FromBody] TodoItem todo)
        {
            var newTodo = await _supabaseClient.From<TodoItem>().Insert(todo);
            return CreatedAtAction(nameof(GetTodos), new { id = newTodo.Id }, newTodo);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTodo([FromBody] TodoItem todo, int id)
        {
            var updatedTodo = await _supabaseClient.From<TodoItem>().Update(todo).Eq("id", id);
            return Ok(updatedTodo);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTodo(int id)
        {
            await _supabaseClient.From<TodoItem>().Delete().Eq("id", id);
            return NoContent();
        }
    }
}
```
