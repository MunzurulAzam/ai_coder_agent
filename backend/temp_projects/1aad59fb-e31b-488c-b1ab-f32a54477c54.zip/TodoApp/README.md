
# Todo App

This is a Todo App built using .NET, React, and Supabase.

## Prerequisites

* .NET 6.0 SDK
* Node.js
* Supabase account

## Installation

1. Install .NET 6.0 SDK from the official Microsoft website.
2. Create a new .NET project using `dotnet new webapi -n TodoAppBackend`.
3. Install required NuGet packages using `dotnet add package Supabase.Net`.
4. Create a new React project using `npx create-react-app frontend --template typescript`.
5. Install required npm packages using `npm install @supabase/supabase-js`.
6. Create a new Supabase project and create a new database schema using the `supabase.sql` file.

## Setup

1. Update `appsettings.json` with your Supabase project credentials.
2. Implement the `TodoController` to interact with the Supabase database.
3. Update `src/services/TodoService.ts` to interact with the backend API.
4. Implement the `TodoList` component to display the todo items.

## Running the Application

1. Start the backend API using `dotnet run`.
2. Start the frontend development server using `npm start`.
3. Open your web browser and navigate to `http://localhost:3000` to view the Todo App.
```
