
```typescript
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

const TodoService = {
  getTodos: async () => {
    const response = await api.get('/todos');
    return response.data;
  },
  getTodo: async (id: number) => {
    const response = await api.get(`/todos/${id}`);
    return response.data;
  },
  createTodo: async (todo: TodoItem) => {
    const response = await api.post('/todos', todo);
    return response.data;
  },
  updateTodo: async (todo: TodoItem) => {
    const response = await api.put(`/todos/${todo.id}`, todo);
    return response.data;
  },
  deleteTodo: async (id: number) => {
    await api.delete(`/todos/${id}`);
  },
};

export default TodoService;
```
