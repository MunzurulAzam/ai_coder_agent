
```typescript
import React, { useState, useEffect } from 'react';
import TodoService from '../services/TodoService';

const TodoList = () => {
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [newTodo, setNewTodo] = useState<string>('');

  useEffect(() => {
    TodoService.getTodos().then((todos) => setTodos(todos));
  }, []);

  const handleAddTodo = () => {
    TodoService.createTodo({ title: newTodo, completed: false })
      .then((todo) => setTodos([...todos, todo]))
      .then(() => setNewTodo(''));
  };

  const handleToggleCompleted = (id: number) => {
    TodoService.getTodo(id).then((todo) => {
      TodoService.updateTodo({ ...todo, completed: !todo.completed });
      setTodos(todos.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
    });
  };

  const handleDeleteTodo = (id: number) => {
    TodoService.deleteTodo(id);
    setTodos(todos.filter((t) => t.id !== id));
  };

  return (
    <div>
      <input
        type="text"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
        placeholder="Add new todo"
      />
      <button onClick={handleAddTodo}>Add</button>
      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            <input
              type="checkbox"
              checked={todo.completed}
              onChange={() => handleToggleCompleted(todo.id)}
            />
            <span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
              {todo.title}
            </span>
            <button onClick={() => handleDeleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
```
