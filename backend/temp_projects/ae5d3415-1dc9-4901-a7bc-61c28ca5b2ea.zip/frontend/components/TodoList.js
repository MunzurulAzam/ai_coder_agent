
```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function TodoList() {
    const [todos, setTodos] = useState([]);
    const [newTodo, setNewTodo] = useState('');

    useEffect(() => {
        axios.get('https://localhost:5001/api/todos')
            .then(response => {
                setTodos(response.data);
            })
            .catch(error => {
                console.error(error);
            });
    }, []);

    const handleCreateTodo = () => {
        axios.post('https://localhost:5001/api/todos', { title: newTodo, completed: false })
            .then(response => {
                setTodos([...todos, response.data]);
                setNewTodo('');
            })
            .catch(error => {
                console.error(error);
            });
    };

    const handleUpdateTodo = (id, title, completed) => {
        axios.put(`https://localhost:5001/api/todos/${id}`, { title, completed })
            .then(response => {
                setTodos(todos.map(todo => todo.id === id ? response.data : todo));
            })
            .catch(error => {
                console.error(error);
            });
    };

    const handleDeleteTodo = (id) => {
        axios.delete(`https://localhost:5001/api/todos/${id}`)
            .then(() => {
                setTodos(todos.filter(todo => todo.id !== id));
            })
            .catch(error => {
                console.error(error);
            });
    };

    return (
        <div>
            <h1>Todo List</h1>
            <input type="text" value={newTodo} onChange={(e) => setNewTodo(e.target.value)} />
            <button onClick={handleCreateTodo}>Create Todo</button>
            <ul>
                {todos.map((todo) => (
                    <li key={todo.id}>
                        <input type="checkbox" checked={todo.completed} onChange={() => handleUpdateTodo(todo.id, todo.title, !todo.completed)} />
                        <span>{todo.title}</span>
                        <button onClick={() => handleDeleteTodo(todo.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default TodoList;
```
