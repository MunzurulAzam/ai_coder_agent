
```markdown
# Todo App with .NET, React, and Supabase

## Overview

This project is a Todo App built with .NET as the backend, React as the frontend, and Supabase as the database.

## Prerequisites

* .NET 6.0 SDK
* Node.js 16.14.2
* Supabase instance

## Setup Guide

### Step 1: Create Supabase Instance

1. Create a Supabase instance on the official website.
2. Note down the instance URL and key.

### Step 2: Create .NET Backend

1. Create a new .NET project using the command `dotnet new webapi -n TodoAppBackend`.
2. Add the `Microsoft.EntityFrameworkCore` package using the command `dotnet add package Microsoft.EntityFrameworkCore`.
3. Create a new file `appsettings.json` and add the following configuration:
```json
{
  "Supabase": {
    "Url": "https://your-supabase-instance-url.supabase.co",
    "Key": "your-supabase-instance-key"
  }
}
```
4. Create a new file `TodoController.cs` and add the following code:
```csharp
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace TodoAppBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoController : ControllerBase
    {
        private readonly TodoAppDbContext _context;

        public TodoController(TodoAppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetTodos()
        {
            var todos = await _context.Todos.ToListAsync();
            return Ok(todos);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTodo(Todo todo)
        {
            _context.Todos.Add(todo);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetTodos), new { id = todo.Id }, todo);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTodo(int id, Todo todo)
        {
            var existingTodo = await _context.Todos.FindAsync(id);
            if (existingTodo == null) return NotFound();
            existingTodo.Title = todo.Title;
            existingTodo.Completed = todo.Completed;
            await _context.SaveChangesAsync();
            return Ok(existingTodo);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTodo(int id)
        {
            var todo = await _context.Todos.FindAsync(id);
            if (todo == null) return NotFound();
            _context.Todos.Remove(todo);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
```
5. Run the .NET backend using the command `dotnet run`.

### Step 3: Create React Frontend

1. Create a new React project using the command `npx create-react-app todo-app-frontend`.
2. Add the `axios` package using the command `npm install axios`.
3. Create a new file `components/TodoList.js` and add the following code:
```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function TodoList() {
    const [todos, setTodos] = useState([]);
    const [newTodo, setNewTodo] = useState('');

    useEffect(() => {
        axios.get('https://localhost:5001/api/todos')
            .then(response => {
                setTodos(response.data);
            })
            .catch(error => {
                console.error(error);
            });
    }, []);

    const handleCreateTodo = () => {
        axios.post('https://localhost:5001/api/todos', { title: newTodo, completed: false })
            .then(response => {
                setTodos([...todos, response.data]);
                setNewTodo('');
            })
            .catch(error => {
                console.error(error);
            });
    };

    const handleUpdateTodo = (id, title, completed) => {
        axios.put(`https://localhost:5001/api/todos/${id}`, { title, completed })
            .then(response => {
                setTodos(todos.map(todo => todo.id === id ? response.data : todo));
            })
            .catch(error => {
                console.error(error);
            });
    };

    const handleDeleteTodo = (id) => {
        axios.delete(`https://localhost:5001/api/todos/${id}`)
            .then(() => {
                setTodos(todos.filter(todo => todo.id !== id));
            })
            .catch(error => {
                console.error(error);
            });
    };

    return (
        <div>
            <h1>Todo List</h1>
            <input type="text" value={newTodo} onChange={(e) => setNewTodo(e.target.value)} />
            <button onClick={handleCreateTodo}>Create Todo</button>
            <ul>
                {todos.map((todo) => (
                    <li key={todo.id}>
                        <input type="checkbox" checked={todo.completed} onChange={() => handleUpdateTodo(todo.id, todo.title, !todo.completed)} />
                        <span>{todo.title}</span>
                        <button onClick={() => handleDeleteTodo(todo.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default TodoList;
```
4. Run the React frontend using the command `npm start`.

### Step 4: Test the App

1. Open a web browser and navigate to `https://localhost:3000`.
2. Create a new todo item by entering a title and clicking the "Create Todo" button.
3. Update a todo item by checking or unchecking the checkbox and clicking the "Update Todo" button.
4. Delete a todo item by clicking the "Delete" button.
```
