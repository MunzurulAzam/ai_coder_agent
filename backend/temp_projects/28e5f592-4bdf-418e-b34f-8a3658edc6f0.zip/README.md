
```markdown
# Todo App

This is a Todo App built using .NET, React, and Supabase.

## Prerequisites

* .NET 6.0 SDK installed
* Node.js (16.14.0 or later) installed
* Supabase account created

## Installing Dependencies

* Run `dotnet restore` in the backend directory to install .NET dependencies
* Run `npm install` in the frontend directory to install React dependencies

## Setting up Environment

* Create a new file `appsettings.json` in the backend directory and add your Supabase configuration
* Create a new file `supabase.config.js` in the frontend directory and add your Supabase configuration

## Running the Application

* Run `dotnet run` in the backend directory to start the .NET API
* Run `npm start` in the frontend directory to start the React app
* Open your web browser and navigate to `http://localhost:3000`
```
