
```csharp
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Supabase.Client;

var builder = WebApplication.CreateBuilder(args);

// Add Supabase configuration
builder.Services.AddSingleton<ISupabaseClient>(provider =>
{
    var supabaseUrl = builder.Configuration["Supabase:Url"];
    var supabaseKey = builder.Configuration["Supabase:Key"];
    var supabaseSecret = builder.Configuration["Supabase:Secret"];

    return new SupabaseClient(supabaseUrl, supabaseKey, supabaseSecret);
});

// Add controllers and services
builder.Services.AddControllers();

var app = builder.Build();

// Configure the HTTP request pipeline
app.UseRouting();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.Run();
```
