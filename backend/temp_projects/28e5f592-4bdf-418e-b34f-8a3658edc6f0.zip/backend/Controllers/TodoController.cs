
```csharp
using Microsoft.AspNetCore.Mvc;
using Supabase.Client;

namespace TodoApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoController : ControllerBase
    {
        private readonly ISupabaseClient _supabaseClient;

        public TodoController(ISupabaseClient supabaseClient)
        {
            _supabaseClient = supabaseClient;
        }

        [HttpGet]
        public async Task<IActionResult> GetTodos()
        {
            var todos = await _supabaseClient.From("todos").Select("*");
            return Ok(todos);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTodo([FromBody] Todo todo)
        {
            var newTodo = await _supabaseClient.From("todos").Insert(todo);
            return CreatedAtAction(nameof(GetTodos), newTodo);
        }
    }

    public class Todo
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
```
