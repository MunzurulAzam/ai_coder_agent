
```javascript
import React, { useState, useEffect } from 'react';
import supabase from '../supabase.config';

function TodoList() {
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    supabase
      .from('todos')
      .select('*')
      .then((data) => setTodos(data.data));
  }, []);

  return (
    <ul>
      {todos.map((todo) => (
        <li key={todo.id}>{todo.title}</li>
      ))}
    </ul>
  );
}

export default TodoList;
```
