# Todo App

## Installing dependencies

*   Navigate to the `backend` directory and run `dotnet restore` to install the required .NET dependencies.
*   Navigate to the `frontend` directory and run `npm install` to install the required React dependencies.

## Setting up environment

*   Create a new Supabase instance and note the `URL` and `KEY`.
*   Create a new file `.env` in the root directory with the respective values.

## Running the application

*   Navigate to the `backend` directory and run `dotnet run` to start the .NET API.
*   Navigate to the `frontend` directory and run `npm start` to start the React App.
*   Open a web browser and navigate to `http://localhost:3000` to access the Todo App.

## Example Use Cases:

*   Create a new Todo item: `curl -X POST http://localhost:5000/api/todos -H 'Content-Type: application/json' -d '{"title": "New Todo item"}'`
*   Get all Todo items: `curl -X GET http://localhost:5000/api/todos`
*   Update a Todo item: `curl -X PUT http://localhost:5000/api/todos/1 -H 'Content-Type: application/json' -d '{"title": "Updated Todo item"}'`
*   Delete a Todo item: `curl -X DELETE http://localhost:5000/api/todos/1`