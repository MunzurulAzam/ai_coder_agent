import React, { useState, useEffect } from 'react';
import TodoList from '../components/TodoList';
import { supabase } from '../utils/supabase';

function App() {
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    const fetchTodos = async () => {
      const { data, error } = await supabase.from('todos').select('*');
      if (error) {
        console.error(error);
      } else {
        setTodos(data);
      }
    };
    fetchTodos();
  }, []);

  const handleCreateTodo = async (title) => {
    const { data, error } = await supabase.from('todos').insert([{ title, completed: false }]);
    if (error) {
      console.error(error);
    } else {
      setTodos([...todos, data[0]]);
    }
  };

  const handleUpdateTodo = async (id, title) => {
    const { data, error } = await supabase.from('todos').update({ id: id, title: title });
    if (error) {
      console.error(error);
    } else {
      setTodos(todos.map((todo) => todo.id === id ? { ...todo, title: title } : todo));
    }
  };

  const handleDeleteTodo = async (id) => {
    const { data, error } = await supabase.from('todos').delete().eq('id', id);
    if (error) {
      console.error(error);
    } else {
      setTodos(todos.filter((todo) => todo.id !== id));
    }
  };

  return (
    &lt;div&gt;
      &lt;h1&gt;Todo App&lt;/h1&gt;
      &lt;TodoList todos={todos} onCreateTodo={handleCreateTodo} onUpdateTodo={handleUpdateTodo} onDeleteTodo={handleDeleteTodo} /&gt;
    &lt;/div&gt;
  );
}

export default App;