import React from 'react';

function TodoList({ todos, onCreateTodo, onUpdateTodo, onDeleteTodo }) {
  return (
    &lt;ul&gt;
      {todos.map((todo) => (
        &lt;li key={todo.id}&gt;
          &lt;input type="checkbox" checked={todo.completed} onChange={() => onUpdateTodo(todo.id, todo.title)} /&gt;
          &lt;span&gt;{todo.title}&lt;/span&gt;
          &lt;button onClick={() => onDeleteTodo(todo.id)}&gt;Delete&lt;/button&gt;
        &lt;/li&gt;
      ))}
      &lt;li&gt;
        &lt;input type="text" placeholder="New todo" onKeyPress={(e) => {
          if (e.key === 'Enter') {
            onCreateTodo(e.target.value);
            e.target.value = '';
          }
        }} /&gt;
      &lt;/li&gt;
    &lt;/ul&gt;
  );
}

export default TodoList;