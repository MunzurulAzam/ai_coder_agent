using Microsoft.AspNetCore.Mvc;
using TodoApp.Api.Models;
using TodoApp.Api.Services;

namespace TodoApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodoController : ControllerBase
    {
        private readonly ITodoService _todoService;

        public TodoController(ITodoService todoService)
        {
            _todoService = todoService;
        }

        // GET: api/todos
        [HttpGet]
        public async Task&lt;ActionResult&lt;IEnumerable&lt;Todo&gt;&gt;&gt; GetTodos()
        {
            return Ok(await _todoService.GetTodosAsync());
        }

        // GET: api/todos/5
        [HttpGet("{id}")]
        public async Task&lt;ActionResult&lt;Todo&gt;&gt; GetTodo(int id)
        {
            return Ok(await _todoService.GetTodoAsync(id));
        }

        // POST: api/todos
        [HttpPost]
        public async Task&lt;ActionResult&lt;Todo&gt;&gt; CreateTodo(Todo todo)
        {
            return Ok(await _todoService.CreateTodoAsync(todo));
        }

        // PUT: api/todos/5
        [HttpPut("{id}")]
        public async Task&lt;ActionResult&lt;Todo&gt;&gt; UpdateTodo(int id, Todo todo)
        {
            return Ok(await _todoService.UpdateTodoAsync(id, todo));
        }

        // DELETE: api/todos/5
        [HttpDelete("{id}")]
        public async Task&lt;ActionResult&gt; DeleteTodo(int id)
        {
            await _todoService.DeleteTodoAsync(id);
            return NoContent();
        }
    }
}