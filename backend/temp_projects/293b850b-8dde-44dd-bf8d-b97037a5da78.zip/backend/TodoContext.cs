using Microsoft.EntityFrameworkCore;
using TodoApp.Api.Models;

public class TodoContext : DbContext
{
    public TodoContext(DbContextOptions&lt;TodoContext&gt; options) : base(options)
    {
    }

    public DbSet&lt;Todo&gt; Todos { get; set; }
}