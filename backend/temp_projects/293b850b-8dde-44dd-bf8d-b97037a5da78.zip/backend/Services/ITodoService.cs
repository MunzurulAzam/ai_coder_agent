using System.Collections.Generic;
using System.Threading.Tasks;
using TodoApp.Api.Models;

namespace TodoApp.Api.Services
{
    public interface ITodoService
    {
        Task&lt;IEnumerable&lt;Todo&gt;&gt; GetTodosAsync();
        Task&lt;Todo&gt; GetTodoAsync(int id);
        Task&lt;Todo&gt; CreateTodoAsync(Todo todo);
        Task&lt;Todo&gt; UpdateTodoAsync(int id, Todo todo);
        Task DeleteTodoAsync(int id);
    }
}