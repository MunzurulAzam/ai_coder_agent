using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TodoApp.Api.Models;

namespace TodoApp.Api.Services
{
    public class TodoService : ITodoService
    {
        private readonly TodoContext _context;

        public TodoService(TodoContext context)
        {
            _context = context;
        }

        public async Task&lt;IEnumerable&lt;Todo&gt;&gt; GetTodosAsync()
        {
            return await _context.Todos.ToListAsync();
        }

        public async Task&lt;Todo&gt; GetTodoAsync(int id)
        {
            return await _context.Todos.FindAsync(id);
        }

        public async Task&lt;Todo&gt; CreateTodoAsync(Todo todo)
        {
            _context.Todos.Add(todo);
            await _context.SaveChangesAsync();
            return todo;
        }

        public async Task&lt;Todo&gt; UpdateTodoAsync(int id, Todo todo)
        {
            var existingTodo = await _context.Todos.FindAsync(id);
            if (existingTodo != null)
            {
                existingTodo.Title = todo.Title;
                existingTodo.Completed = todo.Completed;
                await _context.SaveChangesAsync();
            }
            return existingTodo;
        }

        public async Task DeleteTodoAsync(int id)
        {
            var todo = await _context.Todos.FindAsync(id);
            if (todo != null)
            {
                _context.Todos.Remove(todo);
                await _context.SaveChangesAsync();
            }
        }
    }
}